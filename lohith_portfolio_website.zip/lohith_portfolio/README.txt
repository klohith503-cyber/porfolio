# Kalisetti Lohith Kumar — Portfolio

## Run locally
Open `index.html` in a modern browser. The avatar introduction uses browser text-to-speech (speech synthesis).

## Deploy free on Vercel
1. Extract this ZIP.
2. Upload the `lohith_portfolio` folder to a GitHub repository.
3. In Vercel, choose **Add New → Project**, import the repository.
4. Framework preset: **Other**; Build Command: leave empty; Output Directory: `.`.
5. Deploy.

The site includes the resume PDF and uploaded portrait in `assets/`.
Certificate descriptions are taken from the resume. Upload the individual certificate scans to add actual preview images.
